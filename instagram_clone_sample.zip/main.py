
from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
import jwt
from datetime import datetime, timedelta

app = FastAPI(title="Instagram Clone API", version="1.0.0")

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

# Security concern: Consider using environment variables
SECRET_KEY = "your-secret-key-here"
ALGORITHM = "HS256"

@app.post("/api/v1/auth/register")
async def register(username: str, email: str, password: str):
    """Register a new user"""
    return {"message": "User registered successfully"}

@app.post("/api/v1/auth/login")
async def login(form_data: OAuth2PasswordRequestForm = Depends()):
    """Authenticate user and return JWT token"""
    token = jwt.encode({"sub": form_data.username}, SECRET_KEY, algorithm=ALGORITHM)
    return {"access_token": token, "token_type": "bearer"}

@app.get("/api/v1/posts")
async def get_posts(skip: int = 0, limit: int = 20):
    """Get all posts with pagination"""
    return {"posts": []}

@app.post("/api/v1/posts")
async def create_post(caption: str, image_url: str, token: str = Depends(oauth2_scheme)):
    """Create a new post"""
    return {"post_id": 1, "caption": caption}

@app.post("/api/v1/posts/{post_id}/like")
async def like_post(post_id: int, token: str = Depends(oauth2_scheme)):
    """Like a post"""
    return {"message": "Post liked"}

@app.post("/api/v1/posts/{post_id}/comments")
async def add_comment(post_id: int, text: str, token: str = Depends(oauth2_scheme)):
    """Add comment to a post"""
    return {"comment_id": 1, "text": text}

@app.get("/api/v1/users/{user_id}")
async def get_user_profile(user_id: int):
    """Get user profile"""
    return {"user_id": user_id}
